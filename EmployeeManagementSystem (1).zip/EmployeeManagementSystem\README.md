# 🏢 Java Full Stack Employee Management System (EMS)
> **Java Full Stack Internship Project Submission**

---

## 📌 Project Overview
The **Employee Management System (EMS)** is an enterprise-grade full-stack web application designed for managing company workforce operations, department analytics, leave request workflows, salary payroll disbursal, printable digital ID passes, and CSV data exports.

Built following pure **Java Enterprise Layered Architecture** (Controller -> Service -> Repository -> Model -> DTO), it runs with zero external installation requirements and serves a modern, glassmorphic Single Page Application (SPA) with Dark/Light theme modes.

---

## 🚀 Key Features

1. **👥 Employee Directory & Full CRUD**:
   - Live real-time search by Name, Email, Position, ID, or Department.
   - Filter by Department (Engineering, HR, Sales, Finance, Operations, Design, Marketing).
   - Filter by Employment Status (Active, On Leave, Terminated).
   - Add new employees & edit existing employee details.
   - Delete employee records with confirmation.

2. **📅 Leave Management System**:
   - Employees/Managers can submit leave applications (Annual, Sick, Casual, Maternity).
   - View pending leave requests and approve/reject leave applications with status updates.

3. **💰 Automated Payroll & Payslip Generator**:
   - Calculates base salary, performance bonuses, tax deductions, and net pay.
   - Disburses monthly salaries and previews printable payslips.

4. **📊 Analytics & Department Insights**:
   - Real-time workforce metrics (Total staff, Active headcount, Staff on leave, Total monthly payroll budget).
   - Performance rating metrics and visual progress indicators for department headcount distribution.

5. **🆔 Printable Digital ID Badges**:
   - Generates digital ID passes with avatars, role titles, and employee IDs ready for printing.

6. **📤 Export Capabilities**:
   - Export full employee dataset directly into standard CSV file.

---

## 🛠️ Technology Stack

| Layer | Technology |
|---|---|
| **Backend Language** | Java 24 Enterprise Standard Edition |
| **Server Engine** | `com.sun.net.httpserver.HttpServer` (Embedded REST Server) |
| **Architecture Pattern** | Layered Enterprise (Controller, Service, Repository, Model, DTO) |
| **Database Persistence** | Data File Serialization & Thread-Safe Concurrency Maps |
| **Frontend UI** | HTML5, Vanilla CSS3 (Custom Tokens & Glassmorphism), JavaScript (ES6+) |
| **Styling & Fonts** | Plus Jakarta Sans, Outfit, FontAwesome 6 |

---

## 💻 How to Run the Application

### Option A: One-Click Windows Launcher (Recommended)
Double click `run.bat` or execute in command prompt:
```cmd
cd EmployeeManagementSystem
run.bat
```

### Option B: Command Line (Java 17+)
```bash
# 1. Compile Java source code
mkdir bin
javac -d bin -sourcepath src src/com/ems/Main.java

# 2. Run Main Server
java -cp bin com.ems.Main
```

Once started, open your web browser at:
👉 **`http://localhost:8080`**

---

## 🔑 Default Login Credentials

| Role | Username | Default Password |
|---|---|---|
| **Administrator** | `admin` | `admin123` |
| **HR Manager** | `hrmanager` | `hr123` |
| **Employee** | `employee` | `emp123` |

---

## 📡 REST API Documentation

| Endpoint | Method | Description |
|---|---|---|
| `/api/employees` | `GET` | Retrieve list of employees (supports `q`, `dept`, `status` query params) |
| `/api/employees` | `POST` | Create a new employee |
| `/api/employees/{id}` | `PUT` | Update existing employee |
| `/api/employees/{id}` | `DELETE` | Delete employee record |
| `/api/leaves` | `GET` | Get all leave requests |
| `/api/leaves` | `POST` | Submit a new leave request |
| `/api/leaves/{id}/status` | `PUT` | Approve or Reject a leave request |
| `/api/payroll` | `GET` | Get payroll history |
| `/api/payroll` | `POST` | Generate payslip for employee |
| `/api/stats` | `GET` | Get dashboard overview analytics |
