package com.ems.service;

import com.ems.model.User;
import com.ems.repository.UserRepository;

import java.util.Optional;

public class AuthService {
    private final UserRepository repository;

    public AuthService(UserRepository repository) {
        this.repository = repository;
    }

    public Optional<User> authenticate(String username, String password) {
        Optional<User> userOpt = repository.findByUsername(username);
        if (userOpt.isPresent()) {
            User u = userOpt.get();
            if (u.getPassword().equals(password)) {
                return Optional.of(u);
            }
        }
        return Optional.empty();
    }
}
