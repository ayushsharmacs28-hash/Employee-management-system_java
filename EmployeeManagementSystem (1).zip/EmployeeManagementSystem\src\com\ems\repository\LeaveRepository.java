package com.ems.repository;

import com.ems.model.LeaveRequest;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class LeaveRepository {
    private final Map<String, LeaveRequest> leaveMap = new ConcurrentHashMap<>();
    private final String dataFilePath;

    public LeaveRepository(String dataDirectory) {
        File dir = new File(dataDirectory);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        this.dataFilePath = dataDirectory + File.separator + "leaves.dat";
        loadData();
    }

    public List<LeaveRequest> findAll() {
        return new ArrayList<>(leaveMap.values());
    }

    public Optional<LeaveRequest> findById(String id) {
        return Optional.ofNullable(leaveMap.get(id));
    }

    public LeaveRequest save(LeaveRequest req) {
        if (req.getId() == null || req.getId().trim().isEmpty()) {
            req.setId("LV-" + (5000 + leaveMap.size() + 1));
        }
        leaveMap.put(req.getId(), req);
        saveData();
        return req;
    }

    public List<LeaveRequest> findByEmployeeId(String empId) {
        return leaveMap.values().stream()
                .filter(l -> l.getEmployeeId().equalsIgnoreCase(empId))
                .collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    private void loadData() {
        File file = new File(dataFilePath);
        if (!file.exists()) return;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            List<LeaveRequest> list = (List<LeaveRequest>) ois.readObject();
            for (LeaveRequest l : list) {
                leaveMap.put(l.getId(), l);
            }
        } catch (Exception e) {
            System.err.println("Could not load leave data file: " + e.getMessage());
        }
    }

    private void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(dataFilePath))) {
            oos.writeObject(new ArrayList<>(leaveMap.values()));
        } catch (Exception e) {
            System.err.println("Could not save leave data file: " + e.getMessage());
        }
    }
}
