package com.ems.controller;

import com.ems.model.LeaveRequest;
import com.ems.service.LeaveService;
import com.ems.util.JsonUtil;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class LeaveController implements HttpHandler {
    private final LeaveService leaveService;

    public LeaveController(LeaveService leaveService) {
        this.leaveService = leaveService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange);
        String method = exchange.getRequestMethod().toUpperCase();

        if ("OPTIONS".equals(method)) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if ("GET".equals(method)) {
                List<LeaveRequest> list = leaveService.getAllLeaves();
                sendJsonResponse(exchange, 200, JsonUtil.leaveListToJson(list));
            } else if ("POST".equals(method)) {
                String body = readRequestBody(exchange);
                Map<String, String> params = JsonUtil.parseSimpleJson(body);

                LeaveRequest req = new LeaveRequest();
                req.setEmployeeId(params.get("employeeId"));
                req.setEmployeeName(params.get("employeeName"));
                req.setLeaveType(params.get("leaveType"));
                req.setStartDate(params.get("startDate"));
                req.setEndDate(params.get("endDate"));
                if (params.containsKey("days")) {
                    try { req.setDays(Integer.parseInt(params.get("days"))); } catch (Exception ignored) {}
                }
                req.setReason(params.get("reason"));

                LeaveRequest created = leaveService.submitLeave(req);
                sendJsonResponse(exchange, 201, JsonUtil.toJson(created));
            } else if ("PUT".equals(method)) {
                // Update status (Approve / Reject)
                if (path.matches("^/api/leaves/[^/]+/status$")) {
                    String[] parts = path.split("/");
                    String id = parts[3];
                    String body = readRequestBody(exchange);
                    Map<String, String> params = JsonUtil.parseSimpleJson(body);
                    String status = params.get("status");

                    LeaveRequest updated = leaveService.updateStatus(id, status);
                    if (updated != null) {
                        sendJsonResponse(exchange, 200, JsonUtil.toJson(updated));
                    } else {
                        sendJsonResponse(exchange, 404, "{\"error\":\"Leave request not found\"}");
                    }
                } else {
                    sendJsonResponse(exchange, 400, "{\"error\":\"Invalid status endpoint\"}");
                }
            } else {
                sendJsonResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(exchange, 500, "{\"error\":\"Internal Server Error: " + JsonUtil.escapeJson(e.getMessage()) + "\"}");
        }
    }

    private void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    private void sendJsonResponse(HttpExchange exchange, int statusCode, String responseText) throws IOException {
        byte[] bytes = responseText.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String readRequestBody(HttpExchange exchange) throws IOException {
        InputStream is = exchange.getRequestBody();
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }
}
