package com.ems.controller;

import com.ems.model.Employee;
import com.ems.service.EmployeeService;
import com.ems.util.JsonUtil;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class EmployeeController implements HttpHandler {
    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange);
        String method = exchange.getRequestMethod().toUpperCase();

        if ("OPTIONS".equals(method)) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        String path = exchange.getRequestURI().getPath(); // /api/employees or /api/employees/{id}
        String query = exchange.getRequestURI().getQuery();

        try {
            if ("GET".equals(method)) {
                if (path.matches("^/api/employees/[^/]+$")) {
                    String id = path.substring("/api/employees/".length());
                    Optional<Employee> empOpt = employeeService.getEmployeeById(id);
                    if (empOpt.isPresent()) {
                        sendJsonResponse(exchange, 200, JsonUtil.toJson(empOpt.get()));
                    } else {
                        sendJsonResponse(exchange, 404, "{\"error\":\"Employee not found\"}");
                    }
                } else {
                    Map<String, String> queryParams = parseQueryParams(query);
                    String q = queryParams.getOrDefault("q", "");
                    String dept = queryParams.getOrDefault("dept", "");
                    String status = queryParams.getOrDefault("status", "");

                    List<Employee> list = employeeService.searchEmployees(q, dept, status);
                    sendJsonResponse(exchange, 200, JsonUtil.employeeListToJson(list));
                }
            } else if ("POST".equals(method)) {
                String body = readRequestBody(exchange);
                Map<String, String> params = JsonUtil.parseSimpleJson(body);

                Employee emp = new Employee();
                emp.setName(params.get("name"));
                emp.setEmail(params.get("email"));
                emp.setPhone(params.get("phone"));
                emp.setDepartment(params.get("department"));
                emp.setPosition(params.get("position"));
                if (params.containsKey("salary")) {
                    try { emp.setSalary(Double.parseDouble(params.get("salary"))); } catch (Exception ignored) {}
                }
                emp.setStatus(params.getOrDefault("status", "ACTIVE"));
                if (params.containsKey("performanceRating")) {
                    try { emp.setPerformanceRating(Integer.parseInt(params.get("performanceRating"))); } catch (Exception ignored) {}
                }
                emp.setAvatarUrl(params.get("avatarUrl"));

                Employee created = employeeService.createEmployee(emp);
                sendJsonResponse(exchange, 201, JsonUtil.toJson(created));
            } else if ("PUT".equals(method)) {
                if (path.matches("^/api/employees/[^/]+$")) {
                    String id = path.substring("/api/employees/".length());
                    String body = readRequestBody(exchange);
                    Map<String, String> params = JsonUtil.parseSimpleJson(body);

                    Employee updatedEmp = new Employee();
                    if (params.containsKey("name")) updatedEmp.setName(params.get("name"));
                    if (params.containsKey("email")) updatedEmp.setEmail(params.get("email"));
                    if (params.containsKey("phone")) updatedEmp.setPhone(params.get("phone"));
                    if (params.containsKey("department")) updatedEmp.setDepartment(params.get("department"));
                    if (params.containsKey("position")) updatedEmp.setPosition(params.get("position"));
                    if (params.containsKey("salary")) {
                        try { updatedEmp.setSalary(Double.parseDouble(params.get("salary"))); } catch (Exception ignored) {}
                    }
                    if (params.containsKey("status")) updatedEmp.setStatus(params.get("status"));
                    if (params.containsKey("performanceRating")) {
                        try { updatedEmp.setPerformanceRating(Integer.parseInt(params.get("performanceRating"))); } catch (Exception ignored) {}
                    }
                    if (params.containsKey("avatarUrl")) updatedEmp.setAvatarUrl(params.get("avatarUrl"));

                    Employee result = employeeService.updateEmployee(id, updatedEmp);
                    if (result != null) {
                        sendJsonResponse(exchange, 200, JsonUtil.toJson(result));
                    } else {
                        sendJsonResponse(exchange, 404, "{\"error\":\"Employee not found\"}");
                    }
                } else {
                    sendJsonResponse(exchange, 400, "{\"error\":\"Missing employee ID in URL\"}");
                }
            } else if ("DELETE".equals(method)) {
                if (path.matches("^/api/employees/[^/]+$")) {
                    String id = path.substring("/api/employees/".length());
                    boolean deleted = employeeService.deleteEmployee(id);
                    if (deleted) {
                        sendJsonResponse(exchange, 200, "{\"message\":\"Employee deleted successfully\"}");
                    } else {
                        sendJsonResponse(exchange, 404, "{\"error\":\"Employee not found\"}");
                    }
                } else {
                    sendJsonResponse(exchange, 400, "{\"error\":\"Missing employee ID in URL\"}");
                }
            } else {
                sendJsonResponse(exchange, 455, "{\"error\":\"Method Not Allowed\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(exchange, 500, "{\"error\":\"Internal Server Error: " + JsonUtil.escapeJson(e.getMessage()) + "\"}");
        }
    }

    private void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    private void sendJsonResponse(HttpExchange exchange, int statusCode, String responseText) throws IOException {
        byte[] bytes = responseText.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String readRequestBody(HttpExchange exchange) throws IOException {
        InputStream is = exchange.getRequestBody();
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }

    private Map<String, String> parseQueryParams(String query) {
        Map<String, String> params = new java.util.HashMap<>();
        if (query == null || query.isEmpty()) return params;
        for (String param : query.split("&")) {
            String[] pair = param.split("=");
            if (pair.length > 1) {
                params.put(pair[0], java.net.URLDecoder.decode(pair[1], StandardCharsets.UTF_8));
            } else if (pair.length == 1) {
                params.put(pair[0], "");
            }
        }
        return params;
    }
}
