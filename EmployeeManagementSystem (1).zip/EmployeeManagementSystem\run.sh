#!/bin/bash
echo "========================================================"
echo "  Compiling Java Full Stack Employee Management System"
echo "========================================================"

mkdir -p bin
javac -d bin -sourcepath src $(find src -name "*.java")

if [ $? -ne 0 ]; then
    echo "[ERROR] Compilation failed!"
    exit 1
fi

echo "========================================================"
echo "  Starting Enterprise EMS Server on http://localhost:8080"
echo "========================================================"
java -cp bin com.ems.Main
