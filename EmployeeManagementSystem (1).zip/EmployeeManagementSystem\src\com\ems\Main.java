package com.ems;

import com.ems.controller.*;
import com.ems.model.Employee;
import com.ems.model.LeaveRequest;
import com.ems.repository.*;
import com.ems.service.*;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Executors;

public class Main {
    private static final int PORT = 8080;
    private static final String DATA_DIR = "data";
    private static final String WEB_DIR = "web";

    public static void main(String[] args) {
        try {
            System.out.println("=================================================");
            System.out.println("  JAVA FULL STACK EMPLOYEE MANAGEMENT SYSTEM    ");
            System.out.println("=================================================");
            
            // 1. Initialize Repositories
            EmployeeRepository employeeRepository = new EmployeeRepository(DATA_DIR);
            LeaveRepository leaveRepository = new LeaveRepository(DATA_DIR);
            UserRepository userRepository = new UserRepository();

            // 2. Initialize Seed Data if empty
            seedInitialData(employeeRepository, leaveRepository);

            // 3. Initialize Services
            EmployeeService employeeService = new EmployeeService(employeeRepository);
            LeaveService leaveService = new LeaveService(leaveRepository);
            PayrollService payrollService = new PayrollService(employeeRepository);
            AuthService authService = new AuthService(userRepository);

            // 4. Create embedded HTTP Server
            HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
            server.setExecutor(Executors.newFixedThreadPool(10));

            // 5. Register REST Controllers
            server.createContext("/api/auth", new AuthController(authService));
            server.createContext("/api/employees", new EmployeeController(employeeService));
            server.createContext("/api/leaves", new LeaveController(leaveService));
            server.createContext("/api/payroll", new PayrollController(payrollService));
            server.createContext("/api/stats", new StatsController(employeeService));

            // 6. Register Static Web Asset Handler
            server.createContext("/", new StaticFileHandler(WEB_DIR));

            server.start();
            System.out.println("🚀 Enterprise Java Server started successfully!");
            System.out.println("🌐 Web Application UI: http://localhost:" + PORT + "/");
            System.out.println("📡 REST API Base URL:  http://localhost:" + PORT + "/api/");
            System.out.println("🔑 Default Credentials:");
            System.out.println("    - Admin:    admin / admin123");
            System.out.println("    - HR:       hrmanager / hr123");
            System.out.println("    - Employee: employee / emp123");
            System.out.println("=================================================");
        } catch (Exception e) {
            System.err.println("Fatal error starting EMS server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void seedInitialData(EmployeeRepository empRepo, LeaveRepository leaveRepo) {
        if (empRepo.findAll().isEmpty()) {
            System.out.println("🌱 Seeding sample employee database...");
            empRepo.save(new Employee("EMP-1001", "Alex Morgan", "alex.morgan@techcorp.com", "+1 555-0101", "Engineering", "Senior Lead Engineer", 125000, "ACTIVE", 5, "2022-03-15", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1002", "Sarah Jenkins", "sarah.j@techcorp.com", "+1 555-0102", "Human Resources", "HR Vice President", 105000, "ACTIVE", 4, "2021-06-10", "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1003", "David Chen", "david.chen@techcorp.com", "+1 555-0103", "Engineering", "Full Stack Developer", 95000, "ACTIVE", 5, "2023-01-20", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1004", "Emily Rodriguez", "emily.r@techcorp.com", "+1 555-0104", "Marketing", "Brand Strategy Lead", 88000, "ACTIVE", 4, "2023-04-12", "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1005", "Michael Vance", "michael.vance@techcorp.com", "+1 555-0105", "Finance", "Financial Controller", 112000, "ACTIVE", 5, "2020-09-01", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1006", "Jessica Taylor", "jessica.t@techcorp.com", "+1 555-0106", "Design", "Principal UX Designer", 98000, "ON_LEAVE", 4, "2022-11-05", "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1007", "Robert Kim", "robert.kim@techcorp.com", "+1 555-0107", "Engineering", "DevOps Architect", 118000, "ACTIVE", 5, "2021-10-18", "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1008", "Amanda White", "amanda.w@techcorp.com", "+1 555-0108", "Sales", "Enterprise Account Exec", 92000, "ACTIVE", 3, "2023-08-01", "https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1009", "Vikram Patel", "vikram.p@techcorp.com", "+1 555-0109", "Engineering", "Data Scientist", 108000, "ACTIVE", 5, "2022-01-15", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80"));
            empRepo.save(new Employee("EMP-1010", "Sophia Martinez", "sophia.m@techcorp.com", "+1 555-0110", "Operations", "Operations Director", 115000, "ACTIVE", 4, "2019-05-20", "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=300&q=80"));
        }

        if (leaveRepo.findAll().isEmpty()) {
            leaveRepo.save(new LeaveRequest("LV-5001", "EMP-1006", "Jessica Taylor", "MATERNITY", "2026-08-10", "2026-11-10", 90, "Maternity Leave", "APPROVED", "2026-07-25"));
            leaveRepo.save(new LeaveRequest("LV-5002", "EMP-1003", "David Chen", "ANNUAL", "2026-09-01", "2026-09-07", 7, "Family vacation to California", "PENDING", "2026-08-18"));
            leaveRepo.save(new LeaveRequest("LV-5003", "EMP-1008", "Amanda White", "SICK", "2026-08-15", "2026-08-17", 2, "Flu recovery", "APPROVED", "2026-08-14"));
        }
    }

    private static class StaticFileHandler implements HttpHandler {
        private final String baseDir;

        public StaticFileHandler(String baseDir) {
            this.baseDir = baseDir;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String pathStr = exchange.getRequestURI().getPath();
            if (pathStr.equals("/")) {
                pathStr = "/index.html";
            }

            Path filePath = Paths.get(baseDir, pathStr);
            File file = filePath.toFile();

            if (!file.exists() || file.isDirectory()) {
                file = Paths.get(baseDir, "index.html").toFile();
            }

            if (!file.exists()) {
                String error = "404 Not Found";
                exchange.sendResponseHeaders(404, error.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(error.getBytes());
                }
                return;
            }

            String contentType = getContentType(file.getName());
            byte[] bytes = Files.readAllBytes(file.toPath());
            
            exchange.getResponseHeaders().set("Content-Type", contentType);
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        }

        private String getContentType(String filename) {
            if (filename.endsWith(".html")) return "text/html; charset=UTF-8";
            if (filename.endsWith(".css")) return "text/css; charset=UTF-8";
            if (filename.endsWith(".js")) return "application/javascript; charset=UTF-8";
            if (filename.endsWith(".json")) return "application/json; charset=UTF-8";
            if (filename.endsWith(".png")) return "image/png";
            if (filename.endsWith(".jpg") || filename.endsWith(".jpeg")) return "image/jpeg";
            if (filename.endsWith(".svg")) return "image/svg+xml";
            if (filename.endsWith(".ico")) return "image/x-icon";
            return "application/octet-stream";
        }
    }
}
