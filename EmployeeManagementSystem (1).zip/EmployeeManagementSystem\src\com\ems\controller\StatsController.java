package com.ems.controller;

import com.ems.service.EmployeeService;
import com.ems.util.JsonUtil;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class StatsController implements HttpHandler {
    private final EmployeeService employeeService;

    public StatsController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange);
        String method = exchange.getRequestMethod().toUpperCase();

        if ("OPTIONS".equals(method)) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        try {
            if ("GET".equals(method)) {
                Map<String, Object> stats = employeeService.getDashboardStats();
                
                StringBuilder sb = new StringBuilder("{");
                sb.append("\"totalEmployees\":").append(stats.get("totalEmployees")).append(",");
                sb.append("\"activeEmployees\":").append(stats.get("activeEmployees")).append(",");
                sb.append("\"onLeaveEmployees\":").append(stats.get("onLeaveEmployees")).append(",");
                sb.append("\"totalPayroll\":").append(stats.get("totalPayroll")).append(",");
                sb.append("\"avgSalary\":").append(stats.get("avgSalary")).append(",");
                sb.append("\"avgRating\":\"").append(stats.get("avgRating")).append("\",");
                
                @SuppressWarnings("unchecked")
                Map<String, Long> deptCounts = (Map<String, Long>) stats.get("departmentDistribution");
                sb.append("\"departments\":{");
                int i = 0;
                for (Map.Entry<String, Long> entry : deptCounts.entrySet()) {
                    sb.append("\"").append(JsonUtil.escapeJson(entry.getKey())).append("\":").append(entry.getValue());
                    if (i++ < deptCounts.size() - 1) sb.append(",");
                }
                sb.append("}}");

                sendJsonResponse(exchange, 200, sb.toString());
            } else {
                sendJsonResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(exchange, 500, "{\"error\":\"Internal Server Error: " + JsonUtil.escapeJson(e.getMessage()) + "\"}");
        }
    }

    private void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    private void sendJsonResponse(HttpExchange exchange, int statusCode, String responseText) throws IOException {
        byte[] bytes = responseText.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
