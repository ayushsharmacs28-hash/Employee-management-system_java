package com.ems.repository;

import com.ems.model.User;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class UserRepository {
    private final Map<String, User> userMap = new ConcurrentHashMap<>();

    public UserRepository() {
        // Initialize default demo users
        userMap.put("admin", new User("admin", "admin123", "ADMIN", "System Administrator", "admin@company.com"));
        userMap.put("hrmanager", new User("hrmanager", "hr123", "HR", "Sarah Jenkins (HR)", "hr@company.com"));
        userMap.put("employee", new User("employee", "emp123", "EMPLOYEE", "Alex Morgan", "alex.morgan@company.com"));
    }

    public Optional<User> findByUsername(String username) {
        if (username == null) return Optional.empty();
        return Optional.ofNullable(userMap.get(username.toLowerCase()));
    }

    public void save(User user) {
        if (user != null && user.getUsername() != null) {
            userMap.put(user.getUsername().toLowerCase(), user);
        }
    }
}
