package com.ems.repository;

import com.ems.model.Employee;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class EmployeeRepository {
    private final Map<String, Employee> employeeMap = new ConcurrentHashMap<>();
    private final String dataFilePath;

    public EmployeeRepository(String dataDirectory) {
        File dir = new File(dataDirectory);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        this.dataFilePath = dataDirectory + File.separator + "employees.dat";
        loadData();
    }

    public List<Employee> findAll() {
        return new ArrayList<>(employeeMap.values());
    }

    public Optional<Employee> findById(String id) {
        return Optional.ofNullable(employeeMap.get(id));
    }

    public Employee save(Employee employee) {
        if (employee.getId() == null || employee.getId().trim().isEmpty()) {
            employee.setId("EMP-" + (1000 + employeeMap.size() + 1));
        }
        employeeMap.put(employee.getId(), employee);
        saveData();
        return employee;
    }

    public boolean deleteById(String id) {
        if (employeeMap.containsKey(id)) {
            employeeMap.remove(id);
            saveData();
            return true;
        }
        return false;
    }

    public List<Employee> findByDepartment(String department) {
        return employeeMap.values().stream()
                .filter(e -> e.getDepartment().equalsIgnoreCase(department))
                .collect(Collectors.toList());
    }

    public List<Employee> search(String query) {
        if (query == null || query.trim().isEmpty()) {
            return findAll();
        }
        String q = query.toLowerCase();
        return employeeMap.values().stream()
                .filter(e -> e.getName().toLowerCase().contains(q) ||
                             e.getEmail().toLowerCase().contains(q) ||
                             e.getDepartment().toLowerCase().contains(q) ||
                             e.getPosition().toLowerCase().contains(q) ||
                             e.getId().toLowerCase().contains(q))
                .collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    private void loadData() {
        File file = new File(dataFilePath);
        if (!file.exists()) return;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            List<Employee> list = (List<Employee>) ois.readObject();
            for (Employee e : list) {
                employeeMap.put(e.getId(), e);
            }
        } catch (Exception e) {
            System.err.println("Could not load employee data file: " + e.getMessage());
        }
    }

    private void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(dataFilePath))) {
            oos.writeObject(new ArrayList<>(employeeMap.values()));
        } catch (Exception e) {
            System.err.println("Could not save employee data file: " + e.getMessage());
        }
    }
}
