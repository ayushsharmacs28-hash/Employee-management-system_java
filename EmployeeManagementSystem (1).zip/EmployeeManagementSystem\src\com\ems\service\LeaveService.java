package com.ems.service;

import com.ems.model.LeaveRequest;
import com.ems.repository.LeaveRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class LeaveService {
    private final LeaveRepository repository;

    public LeaveService(LeaveRepository repository) {
        this.repository = repository;
    }

    public List<LeaveRequest> getAllLeaves() {
        return repository.findAll();
    }

    public List<LeaveRequest> getLeavesByEmployee(String empId) {
        return repository.findByEmployeeId(empId);
    }

    public LeaveRequest submitLeave(LeaveRequest req) {
        if (req.getStatus() == null || req.getStatus().isEmpty()) {
            req.setStatus("PENDING");
        }
        if (req.getAppliedDate() == null || req.getAppliedDate().isEmpty()) {
            req.setAppliedDate(LocalDate.now().toString());
        }
        return repository.save(req);
    }

    public LeaveRequest updateStatus(String id, String newStatus) {
        Optional<LeaveRequest> opt = repository.findById(id);
        if (opt.isPresent()) {
            LeaveRequest req = opt.get();
            req.setStatus(newStatus.toUpperCase());
            return repository.save(req);
        }
        return null;
    }
}
