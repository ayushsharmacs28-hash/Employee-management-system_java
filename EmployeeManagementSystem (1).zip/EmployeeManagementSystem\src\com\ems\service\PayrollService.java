package com.ems.service;

import com.ems.model.Employee;
import com.ems.model.Payroll;
import com.ems.repository.EmployeeRepository;

import java.time.LocalDate;
import java.util.*;

public class PayrollService {
    private final EmployeeRepository employeeRepository;
    private final List<Payroll> payrollList = new ArrayList<>();

    public PayrollService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
        generateInitialPayroll();
    }

    public List<Payroll> getAllPayroll() {
        return new ArrayList<>(payrollList);
    }

    public Payroll generatePayslip(String employeeId, String monthYear, double bonus, double deductions) {
        Optional<Employee> empOpt = employeeRepository.findById(employeeId);
        if (empOpt.isPresent()) {
            Employee emp = empOpt.get();
            double base = emp.getSalary();
            double net = base + bonus - deductions;
            Payroll p = new Payroll(
                "PAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                emp.getId(),
                emp.getName(),
                monthYear,
                base,
                bonus,
                deductions,
                net,
                "PAID",
                LocalDate.now().toString()
            );
            payrollList.add(0, p);
            return p;
        }
        return null;
    }

    private void generateInitialPayroll() {
        List<Employee> employees = employeeRepository.findAll();
        String currentMonth = "August 2026";
        int idCount = 1;
        for (Employee e : employees) {
            double bonus = (e.getPerformanceRating() >= 4) ? 500.00 : 200.00;
            double deductions = e.getSalary() * 0.08; // 8% tax/deductions
            double net = e.getSalary() + bonus - deductions;
            payrollList.add(new Payroll(
                "PAY-" + (1000 + idCount++),
                e.getId(),
                e.getName(),
                currentMonth,
                e.getSalary(),
                bonus,
                deductions,
                net,
                "PAID",
                "2026-08-01"
            ));
        }
    }
}
