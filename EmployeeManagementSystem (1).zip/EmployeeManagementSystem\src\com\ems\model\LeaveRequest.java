package com.ems.model;

import java.io.Serializable;

public class LeaveRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String employeeId;
    private String employeeName;
    private String leaveType; // SICK, CASUAL, ANNUAL, MATERNITY
    private String startDate;
    private String endDate;
    private int days;
    private String reason;
    private String status; // PENDING, APPROVED, REJECTED
    private String appliedDate;

    public LeaveRequest() {}

    public LeaveRequest(String id, String employeeId, String employeeName, String leaveType, 
                        String startDate, String endDate, int days, String reason, 
                        String status, String appliedDate) {
        this.id = id;
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.leaveType = leaveType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.days = days;
        this.reason = reason;
        this.status = status;
        this.appliedDate = appliedDate;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }

    public String getEmployeeName() { return employeeName; }
    public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }

    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public int getDays() { return days; }
    public void setDays(int days) { this.days = days; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getAppliedDate() { return appliedDate; }
    public void setAppliedDate(String appliedDate) { this.appliedDate = appliedDate; }
}
