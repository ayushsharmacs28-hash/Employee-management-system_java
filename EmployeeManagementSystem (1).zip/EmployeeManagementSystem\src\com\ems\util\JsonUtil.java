package com.ems.util;

import com.ems.model.Employee;
import com.ems.model.LeaveRequest;
import com.ems.model.Payroll;
import com.ems.model.User;

import java.util.*;

public class JsonUtil {

    public static String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\b", "\\b")
                    .replace("\f", "\\f")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
    }

    public static String toJson(Employee emp) {
        if (emp == null) return "null";
        return String.format(Locale.US,
            "{\"id\":\"%s\",\"name\":\"%s\",\"email\":\"%s\",\"phone\":\"%s\",\"department\":\"%s\",\"position\":\"%s\",\"salary\":%.2f,\"status\":\"%s\",\"performanceRating\":%d,\"joinDate\":\"%s\",\"avatarUrl\":\"%s\"}",
            escapeJson(emp.getId()),
            escapeJson(emp.getName()),
            escapeJson(emp.getEmail()),
            escapeJson(emp.getPhone()),
            escapeJson(emp.getDepartment()),
            escapeJson(emp.getPosition()),
            emp.getSalary(),
            escapeJson(emp.getStatus()),
            emp.getPerformanceRating(),
            escapeJson(emp.getJoinDate()),
            escapeJson(emp.getAvatarUrl())
        );
    }

    public static String toJson(LeaveRequest req) {
        if (req == null) return "null";
        return String.format(Locale.US,
            "{\"id\":\"%s\",\"employeeId\":\"%s\",\"employeeName\":\"%s\",\"leaveType\":\"%s\",\"startDate\":\"%s\",\"endDate\":\"%s\",\"days\":%d,\"reason\":\"%s\",\"status\":\"%s\",\"appliedDate\":\"%s\"}",
            escapeJson(req.getId()),
            escapeJson(req.getEmployeeId()),
            escapeJson(req.getEmployeeName()),
            escapeJson(req.getLeaveType()),
            escapeJson(req.getStartDate()),
            escapeJson(req.getEndDate()),
            req.getDays(),
            escapeJson(req.getReason()),
            escapeJson(req.getStatus()),
            escapeJson(req.getAppliedDate())
        );
    }

    public static String toJson(Payroll p) {
        if (p == null) return "null";
        return String.format(Locale.US,
            "{\"id\":\"%s\",\"employeeId\":\"%s\",\"employeeName\":\"%s\",\"monthYear\":\"%s\",\"baseSalary\":%.2f,\"bonus\":%.2f,\"deductions\":%.2f,\"netPay\":%.2f,\"status\":\"%s\",\"paymentDate\":\"%s\"}",
            escapeJson(p.getId()),
            escapeJson(p.getEmployeeId()),
            escapeJson(p.getEmployeeName()),
            escapeJson(p.getMonthYear()),
            p.getBaseSalary(),
            p.getBonus(),
            p.getDeductions(),
            p.getNetPay(),
            escapeJson(p.getStatus()),
            escapeJson(p.getPaymentDate())
        );
    }

    public static String toJson(User u) {
        if (u == null) return "null";
        return String.format(
            "{\"username\":\"%s\",\"role\":\"%s\",\"name\":\"%s\",\"email\":\"%s\"}",
            escapeJson(u.getUsername()),
            escapeJson(u.getRole()),
            escapeJson(u.getName()),
            escapeJson(u.getEmail())
        );
    }

    public static String employeeListToJson(List<Employee> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            sb.append(toJson(list.get(i)));
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    public static String leaveListToJson(List<LeaveRequest> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            sb.append(toJson(list.get(i)));
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    public static String payrollListToJson(List<Payroll> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            sb.append(toJson(list.get(i)));
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    public static Map<String, String> parseSimpleJson(String json) {
        Map<String, String> map = new HashMap<>();
        if (json == null || json.trim().isEmpty()) return map;
        
        String trimmed = json.trim();
        if (trimmed.startsWith("{")) trimmed = trimmed.substring(1);
        if (trimmed.endsWith("}")) trimmed = trimmed.substring(0, trimmed.length() - 1);

        String[] pairs = trimmed.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
        for (String pair : pairs) {
            String[] keyValue = pair.split(":", 2);
            if (keyValue.length == 2) {
                String key = keyValue[0].trim().replace("\"", "");
                String value = keyValue[1].trim();
                if (value.startsWith("\"") && value.endsWith("\"")) {
                    value = value.substring(1, value.length() - 1);
                }
                map.put(key, unescapeJson(value));
            }
        }
        return map;
    }

    private static String unescapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\n", "\n")
                    .replace("\\r", "\r")
                    .replace("\\t", "\t");
    }
}
