package com.ems.controller;

import com.ems.model.Payroll;
import com.ems.service.PayrollService;
import com.ems.util.JsonUtil;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class PayrollController implements HttpHandler {
    private final PayrollService payrollService;

    public PayrollController(PayrollService payrollService) {
        this.payrollService = payrollService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange);
        String method = exchange.getRequestMethod().toUpperCase();

        if ("OPTIONS".equals(method)) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        try {
            if ("GET".equals(method)) {
                List<Payroll> list = payrollService.getAllPayroll();
                sendJsonResponse(exchange, 200, JsonUtil.payrollListToJson(list));
            } else if ("POST".equals(method)) {
                String body = readRequestBody(exchange);
                Map<String, String> params = JsonUtil.parseSimpleJson(body);

                String empId = params.get("employeeId");
                String monthYear = params.getOrDefault("monthYear", "August 2026");
                double bonus = 0.0;
                double deductions = 0.0;
                if (params.containsKey("bonus")) {
                    try { bonus = Double.parseDouble(params.get("bonus")); } catch (Exception ignored) {}
                }
                if (params.containsKey("deductions")) {
                    try { deductions = Double.parseDouble(params.get("deductions")); } catch (Exception ignored) {}
                }

                Payroll payslip = payrollService.generatePayslip(empId, monthYear, bonus, deductions);
                if (payslip != null) {
                    sendJsonResponse(exchange, 201, JsonUtil.toJson(payslip));
                } else {
                    sendJsonResponse(exchange, 404, "{\"error\":\"Employee not found for payroll generation\"}");
                }
            } else {
                sendJsonResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(exchange, 500, "{\"error\":\"Internal Server Error: " + JsonUtil.escapeJson(e.getMessage()) + "\"}");
        }
    }

    private void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    private void sendJsonResponse(HttpExchange exchange, int statusCode, String responseText) throws IOException {
        byte[] bytes = responseText.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String readRequestBody(HttpExchange exchange) throws IOException {
        InputStream is = exchange.getRequestBody();
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }
}
