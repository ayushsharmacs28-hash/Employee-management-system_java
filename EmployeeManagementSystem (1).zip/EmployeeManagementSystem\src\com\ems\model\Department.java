package com.ems.model;

import java.io.Serializable;

public class Department implements Serializable {
    private static final long serialVersionUID = 1L;

    private String code;
    private String name;
    private String managerName;
    private double budget;
    private int itemCount;

    public Department() {}

    public Department(String code, String name, String managerName, double budget, int itemCount) {
        this.code = code;
        this.name = name;
        this.managerName = managerName;
        this.budget = budget;
        this.itemCount = itemCount;
    }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getManagerName() { return managerName; }
    public void setManagerName(String managerName) { this.managerName = managerName; }

    public double getBudget() { return budget; }
    public void setBudget(double budget) { this.budget = budget; }

    public int getItemCount() { return itemCount; }
    public void setItemCount(int itemCount) { this.itemCount = itemCount; }
}
