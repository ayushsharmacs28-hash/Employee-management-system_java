/* ==========================================================================
   JAVA FULL STACK EMPLOYEE MANAGEMENT SYSTEM - FRONTEND APP ENGINE
   ========================================================================== */

const API_BASE = '/api';
let employeesData = [];
let leavesData = [];
let payrollData = [];

document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

function initApp() {
    setupTabNavigation();
    setupThemeToggle();
    setupEventListeners();
    loadDashboardData();
}

/* --- Theme Management --- */
function setupThemeToggle() {
    const toggleBtn = document.getElementById('theme-toggle');
    const icon = toggleBtn.querySelector('i');
    
    toggleBtn.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        icon.className = newTheme === 'dark' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
    });
}

/* --- Tab Navigation --- */
function setupTabNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const pageTitle = document.getElementById('page-title');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(n => n.classList.remove('active'));
            item.classList.add('active');

            const tabName = item.getAttribute('data-tab');
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.style.display = 'none';
            });

            const activeTab = document.getElementById(`tab-${tabName}`);
            if (activeTab) activeTab.style.display = 'block';

            if (tabName === 'employees') pageTitle.textContent = 'Employee Directory';
            else if (tabName === 'leaves') pageTitle.textContent = 'Leave Management';
            else if (tabName === 'payroll') pageTitle.textContent = 'Payroll & Salary Disbursal';
            else if (tabName === 'analytics') pageTitle.textContent = 'Analytics & Insights';
        });
    });
}

/* --- Global Event Listeners --- */
function setupEventListeners() {
    // Search & Filter
    document.getElementById('search-input').addEventListener('input', fetchFilteredEmployees);
    document.getElementById('filter-dept').addEventListener('change', fetchFilteredEmployees);
    document.getElementById('filter-status').addEventListener('change', fetchFilteredEmployees);

    // Modal triggers
    document.getElementById('open-add-modal-btn').addEventListener('click', () => {
        openEmployeeModal();
    });

    document.getElementById('open-leave-modal-btn').addEventListener('click', () => {
        populateEmployeeDropdown('leave-emp-select');
        openModal('leave-modal');
    });

    document.getElementById('open-payroll-modal-btn').addEventListener('click', () => {
        populateEmployeeDropdown('payroll-emp-select');
        openModal('payroll-modal');
    });

    // Form Submissions
    document.getElementById('employee-form').addEventListener('submit', handleEmployeeSubmit);
    document.getElementById('leave-form').addEventListener('submit', handleLeaveSubmit);
    document.getElementById('payroll-form').addEventListener('submit', handlePayrollSubmit);
    document.getElementById('export-csv-btn').addEventListener('click', exportToCSV);
}

/* --- API Calls & Data Loaders --- */
async function loadDashboardData() {
    await fetchStats();
    await fetchFilteredEmployees();
    await fetchLeaves();
    await fetchPayroll();
}

async function fetchStats() {
    try {
        const res = await fetch(`${API_BASE}/stats`);
        if (!res.ok) return;
        const stats = await res.json();

        document.getElementById('stat-total').textContent = stats.totalEmployees || 0;
        document.getElementById('stat-active').textContent = stats.activeEmployees || 0;
        document.getElementById('stat-leave').textContent = stats.onLeaveEmployees || 0;
        
        const formattedPayroll = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(stats.totalPayroll || 0);
        document.getElementById('stat-payroll').textContent = formattedPayroll;

        // Analytics page
        document.getElementById('analytics-rating').textContent = `${stats.avgRating || '0.0'} / 5.0`;
        const avgSalFormatted = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(stats.avgSalary || 0);
        document.getElementById('analytics-avg-salary').textContent = avgSalFormatted;

        renderDepartmentBreakdown(stats.departments || {});
    } catch (e) {
        console.error("Error fetching stats:", e);
    }
}

async function fetchFilteredEmployees() {
    const q = document.getElementById('search-input').value;
    const dept = document.getElementById('filter-dept').value;
    const status = document.getElementById('filter-status').value;

    const url = `${API_BASE}/employees?q=${encodeURIComponent(q)}&dept=${encodeURIComponent(dept)}&status=${encodeURIComponent(status)}`;

    try {
        const res = await fetch(url);
        if (!res.ok) return;
        employeesData = await res.json();
        renderEmployeeTable(employeesData);
    } catch (e) {
        console.error("Error fetching employees:", e);
    }
}

async function fetchLeaves() {
    try {
        const res = await fetch(`${API_BASE}/leaves`);
        if (!res.ok) return;
        leavesData = await res.json();
        renderLeaveTable(leavesData);
    } catch (e) {
        console.error("Error fetching leaves:", e);
    }
}

async function fetchPayroll() {
    try {
        const res = await fetch(`${API_BASE}/payroll`);
        if (!res.ok) return;
        payrollData = await res.json();
        renderPayrollTable(payrollData);
    } catch (e) {
        console.error("Error fetching payroll:", e);
    }
}

/* --- Table Renderers --- */
function renderEmployeeTable(list) {
    const tbody = document.getElementById('employee-table-body');
    tbody.innerHTML = '';

    if (!list || list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:2rem; color:var(--text-muted);">No employees found matching criteria.</td></tr>`;
        return;
    }

    list.forEach(emp => {
        const tr = document.createElement('tr');

        let statusClass = 'badge-active';
        if (emp.status === 'ON_LEAVE') statusClass = 'badge-leave';
        else if (emp.status === 'TERMINATED') statusClass = 'badge-terminated';

        const stars = '★'.repeat(emp.performanceRating) + '☆'.repeat(5 - emp.performanceRating);

        const formattedSalary = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(emp.salary || 0);

        tr.innerHTML = `
            <td>
                <div class="emp-cell">
                    <img src="${emp.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}" class="emp-avatar" alt="Avatar">
                    <div class="emp-details">
                        <h4>${escapeHtml(emp.name)}</h4>
                        <p>${escapeHtml(emp.email)} | ${escapeHtml(emp.id)}</p>
                    </div>
                </div>
            </td>
            <td>
                <strong>${escapeHtml(emp.department)}</strong>
                <div style="font-size:0.78rem; color:var(--text-muted);">${escapeHtml(emp.position)}</div>
            </td>
            <td><span class="badge ${statusClass}">${escapeHtml(emp.status)}</span></td>
            <td><strong>${formattedSalary}</strong>/yr</td>
            <td><span class="rating-stars">${stars}</span></td>
            <td>${escapeHtml(emp.joinDate || 'N/A')}</td>
            <td style="text-align: right;">
                <button class="action-btn" title="View Digital Badge" onclick="viewDigitalBadge('${emp.id}')"><i class="fa-solid fa-id-card"></i></button>
                <button class="action-btn" title="Edit Employee" onclick="editEmployee('${emp.id}')"><i class="fa-solid fa-pen-to-square"></i></button>
                <button class="action-btn delete" title="Delete Employee" onclick="deleteEmployee('${emp.id}')"><i class="fa-solid fa-trash-can"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function renderLeaveTable(list) {
    const tbody = document.getElementById('leave-table-body');
    tbody.innerHTML = '';

    if (!list || list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:2rem; color:var(--text-muted);">No leave applications found.</td></tr>`;
        return;
    }

    list.forEach(l => {
        const tr = document.createElement('tr');
        let statusClass = 'badge-pending';
        if (l.status === 'APPROVED') statusClass = 'badge-active';
        else if (l.status === 'REJECTED') statusClass = 'badge-terminated';

        tr.innerHTML = `
            <td><strong>${l.id}</strong></td>
            <td>${escapeHtml(l.employeeName)} (${l.employeeId})</td>
            <td><strong>${l.leaveType}</strong></td>
            <td>${l.startDate} to ${l.endDate} (${l.days} days)</td>
            <td><span style="font-size:0.85rem; color:var(--text-muted);">${escapeHtml(l.reason)}</span></td>
            <td><span class="badge ${statusClass}">${l.status}</span></td>
            <td style="text-align: right;">
                ${l.status === 'PENDING' ? `
                    <button class="btn-primary" style="padding:0.35rem 0.65rem; font-size:0.75rem;" onclick="updateLeaveStatus('${l.id}', 'APPROVED')">Approve</button>
                    <button class="btn-outline" style="padding:0.35rem 0.65rem; font-size:0.75rem; color:var(--danger);" onclick="updateLeaveStatus('${l.id}', 'REJECTED')">Reject</button>
                ` : '<span style="font-size:0.75rem; color:var(--text-muted);">Completed</span>'}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function renderPayrollTable(list) {
    const tbody = document.getElementById('payroll-table-body');
    tbody.innerHTML = '';

    if (!list || list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:2rem; color:var(--text-muted);">No payroll records found.</td></tr>`;
        return;
    }

    list.forEach(p => {
        const tr = document.createElement('tr');
        const fmtBase = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(p.baseSalary);
        const fmtBonus = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(p.bonus);
        const fmtDed = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(p.deductions);
        const fmtNet = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(p.netPay);

        tr.innerHTML = `
            <td><strong>${p.id}</strong></td>
            <td>${escapeHtml(p.employeeName)}</td>
            <td>${p.monthYear}</td>
            <td>${fmtBase}</td>
            <td style="color:var(--success);">+${fmtBonus}</td>
            <td style="color:var(--danger);">-${fmtDed}</td>
            <td><strong style="font-size:1rem; color:var(--primary);">${fmtNet}</strong></td>
            <td><span class="badge badge-paid">${p.status}</span></td>
            <td style="text-align: right;">
                <button class="action-btn" title="Print Payslip" onclick="printPayslip('${p.id}')"><i class="fa-solid fa-print"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function renderDepartmentBreakdown(departments) {
    const container = document.getElementById('dept-chart-list');
    container.innerHTML = '';

    const max = Math.max(...Object.values(departments), 1);

    Object.entries(departments).forEach(([dept, count]) => {
        const percentage = Math.round((count / max) * 100);
        const div = document.createElement('div');
        div.innerHTML = `
            <div style="display:flex; justify-content:space-between; font-size:0.9rem; margin-bottom:0.3rem;">
                <strong>${dept}</strong>
                <span>${count} Employees</span>
            </div>
            <div style="height:10px; background:var(--bg-main); border-radius:5px; overflow:hidden;">
                <div style="width:${percentage}%; height:100%; background:linear-gradient(90deg, var(--primary), var(--secondary)); border-radius:5px;"></div>
            </div>
        `;
        container.appendChild(div);
    });
}

/* --- CRUD Functions --- */
function openEmployeeModal(emp = null) {
    const title = document.getElementById('emp-modal-title');
    document.getElementById('employee-form').reset();
    
    if (emp) {
        title.textContent = 'Edit Employee';
        document.getElementById('emp-id').value = emp.id;
        document.getElementById('emp-name').value = emp.name;
        document.getElementById('emp-email').value = emp.email;
        document.getElementById('emp-phone').value = emp.phone;
        document.getElementById('emp-dept').value = emp.department;
        document.getElementById('emp-position').value = emp.position;
        document.getElementById('emp-salary').value = emp.salary;
        document.getElementById('emp-status').value = emp.status;
        document.getElementById('emp-rating').value = emp.performanceRating;
        document.getElementById('emp-avatar').value = emp.avatarUrl || '';
    } else {
        title.textContent = 'Add New Employee';
        document.getElementById('emp-id').value = '';
    }

    openModal('employee-modal');
}

async function handleEmployeeSubmit(e) {
    e.preventDefault();
    const id = document.getElementById('emp-id').value;

    const payload = {
        name: document.getElementById('emp-name').value,
        email: document.getElementById('emp-email').value,
        phone: document.getElementById('emp-phone').value,
        department: document.getElementById('emp-dept').value,
        position: document.getElementById('emp-position').value,
        salary: document.getElementById('emp-salary').value,
        status: document.getElementById('emp-status').value,
        performanceRating: document.getElementById('emp-rating').value,
        avatarUrl: document.getElementById('emp-avatar').value
    };

    const method = id ? 'PUT' : 'POST';
    const url = id ? `${API_BASE}/employees/${id}` : `${API_BASE}/employees`;

    try {
        const res = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            closeModal('employee-modal');
            await loadDashboardData();
        } else {
            alert("Error saving employee.");
        }
    } catch (err) {
        console.error("Save error:", err);
    }
}

function editEmployee(id) {
    const emp = employeesData.find(e => e.id === id);
    if (emp) openEmployeeModal(emp);
}

async function deleteEmployee(id) {
    if (!confirm(`Are you sure you want to delete employee ${id}?`)) return;

    try {
        const res = await fetch(`${API_BASE}/employees/${id}`, { method: 'DELETE' });
        if (res.ok) {
            await loadDashboardData();
        } else {
            alert("Error deleting employee.");
        }
    } catch (err) {
        console.error("Delete error:", err);
    }
}

/* --- Leave Submission --- */
async function handleLeaveSubmit(e) {
    e.preventDefault();
    const empSelect = document.getElementById('leave-emp-select');
    const selectedOption = empSelect.options[empSelect.selectedIndex];

    const payload = {
        employeeId: empSelect.value,
        employeeName: selectedOption.text,
        leaveType: document.getElementById('leave-type').value,
        days: document.getElementById('leave-days').value,
        startDate: document.getElementById('leave-start').value,
        endDate: document.getElementById('leave-end').value,
        reason: document.getElementById('leave-reason').value
    };

    try {
        const res = await fetch(`${API_BASE}/leaves`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            closeModal('leave-modal');
            await fetchLeaves();
        }
    } catch (err) {
        console.error("Leave submission error:", err);
    }
}

async function updateLeaveStatus(id, newStatus) {
    try {
        const res = await fetch(`${API_BASE}/leaves/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });
        if (res.ok) await fetchLeaves();
    } catch (err) {
        console.error("Status update error:", err);
    }
}

/* --- Payroll Handler --- */
async function handlePayrollSubmit(e) {
    e.preventDefault();
    const empId = document.getElementById('payroll-emp-select').value;
    const payload = {
        employeeId: empId,
        monthYear: document.getElementById('payroll-month').value,
        bonus: document.getElementById('payroll-bonus').value,
        deductions: document.getElementById('payroll-deductions').value
    };

    try {
        const res = await fetch(`${API_BASE}/payroll`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            closeModal('payroll-modal');
            await fetchPayroll();
        }
    } catch (err) {
        console.error("Payroll generation error:", err);
    }
}

function printPayslip(payrollId) {
    const p = payrollData.find(item => item.id === payrollId);
    if (!p) return;
    alert(`PRINTING PAYSLIP:\n\nPayslip ID: ${p.id}\nEmployee: ${p.employeeName}\nMonth: ${p.monthYear}\nBase: $${p.baseSalary}\nBonus: $${p.bonus}\nDeductions: $${p.deductions}\nNet Salary Paid: $${p.netPay}`);
}

/* --- Helpers --- */
function populateEmployeeDropdown(elementId) {
    const select = document.getElementById(elementId);
    select.innerHTML = '';
    employeesData.forEach(e => {
        const opt = document.createElement('option');
        opt.value = e.id;
        opt.textContent = `${e.name} (${e.department} - ${e.id})`;
        select.appendChild(opt);
    });
}

function viewDigitalBadge(id) {
    const emp = employeesData.find(e => e.id === id);
    if (!emp) return;

    document.getElementById('badge-avatar').src = emp.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80';
    document.getElementById('badge-name').textContent = emp.name;
    document.getElementById('badge-role').textContent = emp.position;
    document.getElementById('badge-dept').textContent = emp.department;
    document.getElementById('badge-id').textContent = emp.id;

    openModal('badge-modal');
}

function exportToCSV() {
    if (!employeesData || employeesData.length === 0) return;

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "ID,Name,Email,Phone,Department,Position,Salary,Status,PerformanceRating,JoinDate\n";

    employeesData.forEach(e => {
        csvContent += `"${e.id}","${e.name}","${e.email}","${e.phone}","${e.department}","${e.position}",${e.salary},"${e.status}",${e.performanceRating},"${e.joinDate}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `employee_directory_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, "&amp;")
              .replace(/</g, "&lt;")
              .replace(/>/g, "&gt;")
              .replace(/"/g, "&quot;")
              .replace(/'/g, "&#039;");
}
