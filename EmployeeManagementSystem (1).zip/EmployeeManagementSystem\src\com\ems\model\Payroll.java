package com.ems.model;

import java.io.Serializable;

public class Payroll implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String employeeId;
    private String employeeName;
    private String monthYear;
    private double baseSalary;
    private double bonus;
    private double deductions;
    private double netPay;
    private String status; // PAID, PROCESSING, PENDING
    private String paymentDate;

    public Payroll() {}

    public Payroll(String id, String employeeId, String employeeName, String monthYear, 
                   double baseSalary, double bonus, double deductions, double netPay, 
                   String status, String paymentDate) {
        this.id = id;
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.monthYear = monthYear;
        this.baseSalary = baseSalary;
        this.bonus = bonus;
        this.deductions = deductions;
        this.netPay = netPay;
        this.status = status;
        this.paymentDate = paymentDate;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }

    public String getEmployeeName() { return employeeName; }
    public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }

    public String getMonthYear() { return monthYear; }
    public void setMonthYear(String monthYear) { this.monthYear = monthYear; }

    public double getBaseSalary() { return baseSalary; }
    public void setBaseSalary(double baseSalary) { this.baseSalary = baseSalary; }

    public double getBonus() { return bonus; }
    public void setBonus(double bonus) { this.bonus = bonus; }

    public double getDeductions() { return deductions; }
    public void setDeductions(double deductions) { this.deductions = deductions; }

    public double getNetPay() { return netPay; }
    public void setNetPay(double netPay) { this.netPay = netPay; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) { this.paymentDate = paymentDate; }
}
