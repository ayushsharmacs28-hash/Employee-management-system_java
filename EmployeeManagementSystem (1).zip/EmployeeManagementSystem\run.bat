@echo off
echo ========================================================
echo   Compiling Java Full Stack Employee Management System
echo ========================================================

if not exist bin mkdir bin

javac -d bin -sourcepath src src\com\ems\Main.java src\com\ems\model\*.java src\com\ems\repository\*.java src\com\ems\service\*.java src\com\ems\controller\*.java src\com\ems\util\*.java

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Compilation failed! Please check Java compiler output above.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo ========================================================
echo   Starting Enterprise EMS Server on http://localhost:8080
echo ========================================================
java -cp bin com.ems.Main
pause
