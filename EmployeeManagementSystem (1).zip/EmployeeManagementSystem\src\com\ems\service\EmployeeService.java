package com.ems.service;

import com.ems.model.Employee;
import com.ems.repository.EmployeeRepository;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeService {
    private final EmployeeRepository repository;

    public EmployeeService(EmployeeRepository repository) {
        this.repository = repository;
    }

    public List<Employee> getAllEmployees() {
        return repository.findAll();
    }

    public Optional<Employee> getEmployeeById(String id) {
        return repository.findById(id);
    }

    public Employee createEmployee(Employee employee) {
        if (employee.getJoinDate() == null || employee.getJoinDate().isEmpty()) {
            employee.setJoinDate(java.time.LocalDate.now().toString());
        }
        if (employee.getAvatarUrl() == null || employee.getAvatarUrl().isEmpty()) {
            employee.setAvatarUrl("https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80");
        }
        if (employee.getStatus() == null || employee.getStatus().isEmpty()) {
            employee.setStatus("ACTIVE");
        }
        return repository.save(employee);
    }

    public Employee updateEmployee(String id, Employee updated) {
        Optional<Employee> existingOpt = repository.findById(id);
        if (existingOpt.isPresent()) {
            Employee existing = existingOpt.get();
            if (updated.getName() != null) existing.setName(updated.getName());
            if (updated.getEmail() != null) existing.setEmail(updated.getEmail());
            if (updated.getPhone() != null) existing.setPhone(updated.getPhone());
            if (updated.getDepartment() != null) existing.setDepartment(updated.getDepartment());
            if (updated.getPosition() != null) existing.setPosition(updated.getPosition());
            if (updated.getSalary() > 0) existing.setSalary(updated.getSalary());
            if (updated.getStatus() != null) existing.setStatus(updated.getStatus());
            if (updated.getPerformanceRating() > 0) existing.setPerformanceRating(updated.getPerformanceRating());
            if (updated.getAvatarUrl() != null) existing.setAvatarUrl(updated.getAvatarUrl());
            return repository.save(existing);
        }
        return null;
    }

    public boolean deleteEmployee(String id) {
        return repository.deleteById(id);
    }

    public List<Employee> searchEmployees(String query, String dept, String status) {
        List<Employee> results = repository.search(query);
        
        if (dept != null && !dept.isEmpty() && !dept.equalsIgnoreCase("ALL")) {
            results = results.stream()
                    .filter(e -> e.getDepartment().equalsIgnoreCase(dept))
                    .collect(Collectors.toList());
        }

        if (status != null && !status.isEmpty() && !status.equalsIgnoreCase("ALL")) {
            results = results.stream()
                    .filter(e -> e.getStatus().equalsIgnoreCase(status))
                    .collect(Collectors.toList());
        }

        return results;
    }

    public Map<String, Object> getDashboardStats() {
        List<Employee> all = repository.findAll();
        long totalEmployees = all.size();
        long activeEmployees = all.stream().filter(e -> "ACTIVE".equalsIgnoreCase(e.getStatus())).count();
        long onLeaveEmployees = all.stream().filter(e -> "ON_LEAVE".equalsIgnoreCase(e.getStatus())).count();
        
        double totalPayroll = all.stream().mapToDouble(Employee::getSalary).sum();
        double avgSalary = totalEmployees > 0 ? totalPayroll / totalEmployees : 0;
        double avgRating = all.stream().mapToInt(Employee::getPerformanceRating).average().orElse(0.0);

        Map<String, Long> deptCounts = all.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment, Collectors.counting()));

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalEmployees", totalEmployees);
        stats.put("activeEmployees", activeEmployees);
        stats.put("onLeaveEmployees", onLeaveEmployees);
        stats.put("totalPayroll", totalPayroll);
        stats.put("avgSalary", avgSalary);
        stats.put("avgRating", String.format(Locale.US, "%.1f", avgRating));
        stats.put("departmentDistribution", deptCounts);

        return stats;
    }
}
